import { useEffect, useState } from 'react';

const asset = (filename: string) => `${import.meta.env.BASE_URL}images/${filename}`;

type PhotoProps = {
  src: string;
  alt: string;
  className: string;
  width: number;
  height: number;
  priority?: boolean;
};

function Photo({ src, alt, className, width, height, priority = false }: PhotoProps) {
  const [failed, setFailed] = useState(false);
  if (failed) return <div className={`${className} photo-fallback`} role="img" aria-label={alt} />;
  return (
    <img
      src={src}
      alt={alt}
      className={className}
      width={width}
      height={height}
      loading={priority ? 'eager' : 'lazy'}
      fetchPriority={priority ? 'high' : 'auto'}
      onError={() => setFailed(true)}
    />
  );
}

const navItems = [
  { href: '#home', label: 'Home' },
  { href: '#about', label: 'About' },
  { href: '#facilities', label: 'Facilities' },
  { href: '#training', label: 'Training' },
  { href: '#contact', label: 'Contact' },
];

function Brand() {
  return (
    <a className="brand" href="#home" aria-label="IRON DISTRICT home">
      <span className="brand-mark" aria-hidden="true">I</span>
      <span>IRON<br />DISTRICT</span>
    </a>
  );
}

function Arrow() {
  return <span className="arrow" aria-hidden="true">↗</span>;
}

function Home() {
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const closeOnEscape = (event: KeyboardEvent) => {
      if (event.key === 'Escape') setMenuOpen(false);
    };
    window.addEventListener('keydown', closeOnEscape);
    return () => window.removeEventListener('keydown', closeOnEscape);
  }, []);

  const closeMenu = () => setMenuOpen(false);

  return (
    <div className="homepage">
      <header className="site-header">
        <nav className="nav-inner" aria-label="Main navigation">
          <Brand />
          <button
            type="button"
            className="menu-toggle"
            aria-label={menuOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={menuOpen}
            aria-controls="primary-links"
            onClick={() => setMenuOpen((open) => !open)}
          >
            <span /><span />
          </button>
          <div id="primary-links" className={`nav-links${menuOpen ? ' mobile-open' : ''}`}>
            {navItems.map((item) => (
              <a key={item.href} href={item.href} onClick={closeMenu}>{item.label}</a>
            ))}
            <a className="nav-cta" href="#contact" onClick={closeMenu}>JOIN THE MOVEMENT <Arrow /></a>
          </div>
        </nav>
      </header>

      <main>
        <section className="hero" id="home" aria-labelledby="hero-title">
          <Photo
            src={asset('iron-hero.jpg')}
            alt="A cinematic strength gym with steel racks and free weights under dramatic overhead light"
            className="hero-photo"
            width={1920}
            height={1080}
            priority
          />
          <div className="hero-content">
            <div className="hero-copy">
              <p className="eyebrow reveal">BUILT FOR MORE.</p>
              <h1 id="hero-title" className="display reveal-delay">
                <span>YOUR</span>
                <span className="lime">STRENGTH.</span>
                <span>YOUR</span>
                <span>STANDARD.</span>
              </h1>
              <p className="hero-lede reveal-delay">Train with purpose. Build real strength. Become the strongest version of yourself.</p>
              <div className="hero-actions reveal-delay">
                <a className="button button-primary" href="#contact">START YOUR JOURNEY <Arrow /></a>
                <a className="button button-outline" href="#facilities">EXPLORE THE GYM <Arrow /></a>
              </div>
            </div>
          </div>
          <div className="hero-bottom">
            <div className="value-strip" aria-label="Our focus">
              <span>STRENGTH TRAINING</span>
              <span>PERFORMANCE</span>
              <span>PERSONAL GROWTH</span>
            </div>
            <a className="scroll-cue" href="#about" aria-label="Scroll to introduction">
              <span>SCROLL TO EXPLORE</span><i className="scroll-line" />
            </a>
          </div>
        </section>

        <section className="intro" id="about" aria-labelledby="about-title">
          <div className="section-wrap intro-grid">
            <div className="intro-copy">
              <p className="eyebrow section-label">MORE THAN A WORKOUT.</p>
              <h2 id="about-title" className="display">
                <span>DISCIPLINE</span>
                <span className="muted">BUILDS WHAT</span>
                <span>MOTIVATION</span>
                <span>CANNOT.</span>
              </h2>
              <p>Real progress comes from showing up, putting in the work, and pushing beyond your previous limits. Every session is an opportunity to become stronger.</p>
            </div>
            <figure className="intro-image-wrap">
              <Photo
                src={asset('iron-training.jpg')}
                alt="An athlete, seen from behind, preparing to train with a loaded barbell"
                className="intro-image"
                width={900}
                height={1100}
              />
              <figcaption className="image-caption">SHOW UP. PUT IN THE WORK.</figcaption>
            </figure>
          </div>
        </section>

        <section className="training" id="training" aria-labelledby="training-title">
          <div className="section-wrap">
            <div className="training-top">
              <div>
                <p className="eyebrow section-label">FIND YOUR EDGE.</p>
                <h2 id="training-title" className="section-heading display">BUILT BY THE WORK.</h2>
              </div>
              <p className="training-note">Different paths. One standard: show up ready to move forward.</p>
            </div>
            <div className="training-list">
              <article className="training-row">
                <span className="training-number">01</span>
                <h3>STRENGTH</h3>
                <p>Build a stronger foundation through focused resistance training.</p>
                <span className="row-mark" aria-hidden="true">↗</span>
              </article>
              <article className="training-row">
                <span className="training-number">02</span>
                <h3>CONDITIONING</h3>
                <p>Develop endurance, movement, and overall performance.</p>
                <span className="row-mark" aria-hidden="true">↗</span>
              </article>
              <article className="training-row">
                <span className="training-number">03</span>
                <h3>PERSONAL TRAINING</h3>
                <p>Train with a structured approach tailored to individual goals.</p>
                <span className="row-mark" aria-hidden="true">↗</span>
              </article>
            </div>
          </div>
        </section>

        <section className="facilities" id="facilities" aria-labelledby="facilities-title">
          <div className="section-wrap">
            <div className="facilities-head">
              <div>
                <p className="eyebrow section-label">ROOM TO GET STRONGER.</p>
                <h2 id="facilities-title" className="section-heading display">
                  <span>YOUR WORKSPACE</span>
                  <span className="outline">FOR GREATNESS.</span>
                </h2>
              </div>
              <p className="facilities-intro">A considered training environment, imagined for focus, effort, and the next rep.</p>
            </div>
            <div className="gallery">
              <figure className="gallery-figure">
                <Photo
                  src={asset('iron-floor.jpg')}
                  alt="A spacious, atmospheric strength training floor with racks and a long view through the gym"
                  className="gallery-photo"
                  width={1400}
                  height={1000}
                />
                <figcaption><span>01 — THE TRAINING FLOOR</span><span>FOCUS / FORM</span></figcaption>
              </figure>
              <figure className="gallery-figure">
                <Photo
                  src={asset('iron-hero.jpg')}
                  alt="Strength equipment and iron plates in a dramatic graphite-toned training space"
                  className="gallery-photo"
                  width={1000}
                  height={650}
                />
                <figcaption><span>02 — STRENGTH IN DETAIL</span><span>IRON / INTENT</span></figcaption>
              </figure>
              <figure className="gallery-figure">
                <Photo
                  src={asset('iron-training.jpg')}
                  alt="A focused athlete preparing for a barbell training session"
                  className="gallery-photo"
                  width={1000}
                  height={650}
                />
                <figcaption><span>03 — READY FOR THE WORK</span><span>EFFORT / EVERY DAY</span></figcaption>
              </figure>
            </div>
            <p className="concept-note">A visual concept for IRON DISTRICT. Details shown are illustrative and subject to change.</p>
          </div>
        </section>

        <section className="closing" id="contact" aria-labelledby="closing-title">
          <Photo
            src={asset('iron-finale.jpg')}
            alt="An athlete lifting a barbell in a pool of light inside a dark training space"
            className="closing-photo"
            width={1920}
            height={1080}
          />
          <div className="closing-inner">
            <p className="eyebrow section-label">YOUR MOVE.</p>
            <h2 id="closing-title" className="display">
              <span>THE NEXT LEVEL</span>
              <span className="accent">STARTS WITH YOU.</span>
            </h2>
            <p>Set your standard. Commit to the process. Start building your stronger future.</p>
            <a className="button button-primary" href="#training">LET'S GET STARTED <Arrow /></a>
          </div>
        </section>
      </main>

      <footer className="footer">
        <div className="footer-main">
          <div className="footer-brand">
            <Brand />
            <p>Built for more. A place to put in the work, find your strength, and keep moving forward.</p>
          </div>
          <div className="footer-col">
            <h3>EXPLORE</h3>
            <nav className="footer-links" aria-label="Footer navigation">
              {navItems.map((item) => <a key={item.href} href={item.href}>{item.label}</a>)}
            </nav>
          </div>
          <div className="footer-col">
            <h3>THE DISTRICT</h3>
            <p className="footer-social">A strength-training concept. Social channels and contact details to be added.</p>
          </div>
        </div>
        <div className="footer-bottom">
          <span>© {new Date().getFullYear()} IRON DISTRICT. ALL RIGHTS RESERVED.</span>
          <span>BUILT FOR MORE.</span>
        </div>
      </footer>
    </div>
  );
}

function App() {
  return <Home />;
}

export default App;
